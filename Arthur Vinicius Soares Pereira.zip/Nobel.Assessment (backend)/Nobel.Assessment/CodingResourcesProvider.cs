﻿using System.Text.Json;

namespace Nobel.Assessment
{
    public class CodingResourcesProvider
    {
        /// <summary>
        /// Get all unique topics from available coding resources
        /// </summary>
        /// <returns>Collection of topics</returns>
        public static async Task<ICollection<string>> GetTopics()
        {
            const string URL = "https://api.sampleapis.com/codingresources/codingResources";

            var topics = new HashSet<string>();
            using var httpClient = new HttpClient();

            try
            {
                var response = await httpClient.GetStringAsync(URL);
                var resources = JsonSerializer.Deserialize<List<CodingResource>>(response, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                if (resources == null)
                {
                    return topics;
                }

                foreach (var resource in resources)
                {
                    topics.UnionWith(resource.Topics);
                }

                return topics;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Could not get topics from sample APIs: {ex.Message}");

                return topics;
            }
        }
    }
}
