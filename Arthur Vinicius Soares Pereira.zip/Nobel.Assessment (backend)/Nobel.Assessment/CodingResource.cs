﻿namespace Nobel.Assessment
{
    public class CodingResource
    {
        public ICollection<string> Topics { get; set; } = new List<string>();
    }
}
