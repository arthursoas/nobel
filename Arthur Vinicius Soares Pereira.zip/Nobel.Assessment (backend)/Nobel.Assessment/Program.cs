﻿using Nobel.Assessment;

var topics = await CodingResourcesProvider.GetTopics();

foreach (var topic in topics)
{
    Console.WriteLine(topic);
}

Console.ReadKey();