$(document).ready(function() {
  const campaignInfo = initializeCampaignInfo();
  initializeForm(campaignInfo);
  updateIntro(campaignInfo);
  initializeCodingResourcesTable();
});

function initializeCampaignInfo() {
  const campaignInfo = window.localStorage.getItem('campaign-info');

  if (!campaignInfo) {
    const campaignInfoObj = {
      id: 144,
      firstName: 'Will',
      lastName: 'Smith',
      city: 'Los Angeles',
      state: 'California',
      zip: '90077',
      company: 'Bel-Air Academy',
      intro: 'Agent: Hello and thank you for calling Nobel! My name is Arthur, and I\'m here to assist you today. May I have the pleasure of knowing whom I\' speaking with? \nCustomer: Hi, I\'m {{firstName}} {{lastName}}. \nAgent: Thank you, {{firstName}} {{lastName}}! How can I assist you today?'
    }
    saveCampaignInfo(campaignInfoObj);
    return campaignInfoObj;
  } else {
    return JSON.parse(campaignInfo);
  }
}

function saveCampaignInfo(campaignInfo) {
  window.localStorage.setItem('campaign-info', JSON.stringify(campaignInfo));
}

function initializeForm(campaignInfo) {
  $('#page-title').html(`Campaign ${campaignInfo.id}`);

  $('#first-name-input').val(campaignInfo.firstName); 
  $('#last-name-input').val(campaignInfo.lastName); 
  $('#city-input').val(campaignInfo.city); 
  $('#state-input').val(campaignInfo.state); 
  $('#zip-input').val(campaignInfo.zip);
  $('#company-input').val(campaignInfo.company);

  $('#first-name-input').on('input', function() {
    campaignInfo.firstName = $(this).val();
    saveCampaignInfo(campaignInfo);
    updateIntro(campaignInfo);
  });

  $('#last-name-input').on('input', function() {
    campaignInfo.lastName = $(this).val();
    saveCampaignInfo(campaignInfo);
    updateIntro(campaignInfo);
  });

  $('#city-input').on('input', function() {
    campaignInfo.city = $(this).val();
    saveCampaignInfo(campaignInfo);
  });

  $('#state-input').on('input', function() {
    campaignInfo.state = $(this).val();
    saveCampaignInfo(campaignInfo);
  });

  $('#zip-input').on('input', function() {
    campaignInfo.zip = $(this).val();
    saveCampaignInfo(campaignInfo);
  });

  $('#company-input').on('input', function() {
    campaignInfo.company = $(this).val();
    saveCampaignInfo(campaignInfo);
  });
}

function updateIntro(campaignInfo) {
  let introContent = campaignInfo.intro.replace(/\n/g, '<br><br>');
  introContent = introContent.replace(/{{firstName}}/g, campaignInfo.firstName);
  introContent = introContent.replace(/{{lastName}}/g, campaignInfo.lastName);

  $('#intro-paragraph').html(introContent);
}

async function initializeCodingResourcesTable() {
  const httpResponse = await fetch('https://api.sampleapis.com/codingresources/codingResources');
  const codingResources = await httpResponse.json();

  codingResources.forEach(resource => {
    const type = resource.types[0];

    $('#coding-resources-table-body').append(`
      <tr>
        <td><a href=${resource.url} target=_blank>${resource.description}</a></td>
        <td>${type.charAt(0).toUpperCase() + type.slice(1)}</td>
        <td>${resource.topics.join(', ')}</td>
      </tr>
    `);
  });
}