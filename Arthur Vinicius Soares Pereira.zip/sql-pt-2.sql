CREATE PROCEDURE GetFilteredCampaignData
    @CampaignId INT = NULL,
    @AgentId INT = NULL,
    @Finalid INT = NULL
AS
BEGIN
    SELECT
        c.NOMBRE AS CampaignName,
        c.IDCAMPANYA AS CampaignID,
        u.NOMBRE AS AgentName,
        u.IDUSUARIO AS AgentID,
        u.LOGIN AS AgentLogin,
        COUNT(1) AS Total,
        SUM(CASE WHEN t.tInicio >= c.TINICIAL AND t.tFinal <= c.TFINAL THEN 1 ELSE 0 END) AS TotalInPeriod
    FROM dbo.CAMPANYA AS c
    LEFT JOIN dbo.TRANSACCION AS t
        ON t.idCampanya = c.IDCAMPANYA
    INNER JOIN dbo.USUARIO AS u
        ON u.IDUSUARIO = t.idAgent
    WHERE 
        (c.IDCAMPANYA = @CampaignId) AND
        (u.IDUSUARIO = @AgentId) AND
        (t.idFinal = @Finalid)
    GROUP BY c.NOMBRE, c.IDCAMPANYA, u.NOMBRE, u.IDUSUARIO, u.LOGIN;
END;